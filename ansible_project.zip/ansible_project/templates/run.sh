#!/bin/bash
export SSL_CERT_DIR=/etc/ssl/certs
source /opt/example/venv/bin/activate
exec gunicorn --workers 3 --bind unix:/opt/example/example.sock app:app
exec gunicorn --workers 3 --bind 0.0.0.0:5000 app:wsgi

